package com.mukesh.springbsdk.controller;

import java.security.SecureRandom;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mukesh.springbsdk.dao.User;
import com.mukesh.springbsdk.dao.UserRepository;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class UserController {
	
	@Autowired
	private UserRepository repo;
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	@GetMapping("/index")
	public String viewHomePage()
	{
		return "index";
	}
	
//	Custom login mapping
	@GetMapping("/login")
	public String viewLoginPage(Model model) {
		model.addAttribute("user", new User());
		return "login";
	}
	
	@GetMapping("/signup")
	public String showSignup(Model model) {
		model.addAttribute("user", new User());
		return "signup";
	}
	
	@PostMapping("/process_register")
	public String userDaal(User user)
	{
//		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		char[] chars = "abcdefghijklmnopqrstuvwxyz1234567890".toCharArray();
		StringBuilder sb = new StringBuilder();
		Random random = new SecureRandom();
		for (int i = 0; i < 5; i++) {
			char c = chars[random.nextInt(chars.length)];
			sb.append(c);
		}
		String refCode = sb.toString();
		user.setReferralCode(refCode);
		repo.save(user);
		return "registeredSuccess";
	}
	
	@PostMapping("/process")
	public String loginCheck(User user) {
		String email = user.getEmail();
		String password = user.getPassword();
		CharSequence cs = password;
		
		User realUser = repo.getUserByUserName(email);
		if(realUser!=null)
		{
			String realUserPassword = realUser.getPassword();
			if(passwordEncoder.matches(cs,realUserPassword))
				return "registeredSuccess";
		}
		return "index";
	}
	
	
}
